#include "Array.h"

class RangeArray : public Array{
	protected:
		int low;
		int high;
	public:
		RangeArray(int, int);
		~RangeArray();
		int baseValue();
		int endValue();
		int& operator [](int k);
		int operator [](int k)const;
};
