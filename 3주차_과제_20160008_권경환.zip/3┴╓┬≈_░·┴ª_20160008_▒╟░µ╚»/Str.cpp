#include "Str.h"

Str::Str(int leng){
	str=new char[leng];
	len=leng;
}

Str::Str(char *neyong){
	len=strlen(neyong);
	str=new char[len];
	strcpy(str, neyong);
}

Str::~Str(){
	delete [] str;
}

int Str::length(void){
	return len;
}

char* Str::contents(void){
	return str;
}

int Str::compare(class Str& a){
	int retval=0;
	if(strcmp(this->str, a.str)==0)retval=0;
	else retval=1;

	return retval;
}

int Str::compare(char *a){
	int retval=0;
	if(strcmp(str, a)==0)retval=0;
	else retval=1;
	return retval;
}

void Str::operator=(char*a){
	delete [] str;
	int lenup=strlen(a);
	this->str=new char[lenup];
	strcpy(this->str, a);
	len=lenup;
	return;
}

void Str::operator=(class Str& a){
	delete [] str;
	int lenup=a.length();
	this->str=new char[lenup];
	strcpy(this->str, a.str);
	len=lenup;
	return;
}
